# GIF Your Sorrows Away

GYSA (GIF Your Sorrows Away) is a browser extension that displays adorable GIFs of cute animals on your screen at random.

![](images/banner.gif)
